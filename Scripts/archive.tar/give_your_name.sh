#!/bin/bash

read -p "Give me your name: " name

echo "Your name is", $name





