#!/bin/bash

# A hello world bash function
function_example () {
  echo "Hello World!"
}

# Invoking the hello_world function
function_example
