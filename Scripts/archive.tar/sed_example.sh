!/bin/bash

phrase="myfile"

sed -n "/$phrase/p" myfile.txt

